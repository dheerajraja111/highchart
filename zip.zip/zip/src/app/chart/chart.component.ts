import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})
export class ChartComponent {

  chart = new Chart({
    chart:{
      backgroundColor: '#336196',
      renderTo: 'container',
      type: 'pie'
    },
    title: {
      text: "What's using data",
      style: {
        "color": "#fff"
      }
    },
    series: [{
      name: 'Browsers',
      data: [{
        y: 8,
        name: "Apple TV",
        color: "#A9F3D9"
      }, {
        y: 4,
        name: "Edith Macbook",
        color: "#81C1ED"
      }, {
        y: 2,
        name: "Nexus 6",
        color: "#589CD9"
      }, {
        y: 1,
        name: "Other devices",
        color: "#4279B3"
      }],
      size: '60%',
      innerSize: '70%',
    }]

  });
  function(chart){
    var textX = chart.plotLeft + (chart.plotWidth * 0.5);
    var textY = chart.plotTop + (chart.plotHeight * 0.52);

    var span = '<div id="pieChartInfoText" style="position:absolute; text-align:center;">';
    span += '<div style="color:#fff;font-size: 20px;width:50px">6 GB</div><br>';
    span += '</div>';

  }

// chart = new Chart({
//     chart:{
//       type: 'line'
//     },
//     series: [{
//       name: 'Line 1',
//       data: [1,2,3]
//     }]
//   });

}
